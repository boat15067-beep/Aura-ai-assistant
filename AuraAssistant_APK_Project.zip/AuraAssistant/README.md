# Aura AI Assistant – Android APK

Ye project AuraWebsite folder ko Android WebView mein chalata hai.
Website ki files `app/src/main/assets/` mein hain (index.html, css/, js/, manifest.webmanifest).

## Option A: GitHub par APK apne-aap banwayein (bina Android Studio)
1. GitHub par ek naya repository banayein (private ho to bhi chalega).
2. Is `AuraAssistant` folder ki saari files repository mein upload karein.
   (Folder ke andar ki files upload karein, folder ko zip karke nahi.)
3. Repository mein **Actions** tab kholen → **Build APK** workflow chalne dein.
4. Workflow complete hone par us run ke neeche **Artifacts** mein `AuraAssistant-debug-apk` milegi. Download karke zip khol kar `app-debug.apk` install karein.

## Option B: Android Studio mein APK banayein
1. Android Studio kholen → **Open** → `AuraAssistant` folder select karein.
2. Gradle sync hone dein.
3. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
4. APK milegi: `app/build/outputs/apk/debug/app-debug.apk`.

## Website update karna
Website ki files badalne par unhe `app/src/main/assets/` mein copy karein, phir APK dobara banayein (push karne par Option A apne-aap dobara build karega).

## Notes
- App mein **Settings (⋯)** se Gemini API key daalein.
- Mic (voice input) WebView mein kaam nahi karta.
- Play Store ke liye release build sign karni hogi. Abhi wali debug APK personal install ke liye hai.
